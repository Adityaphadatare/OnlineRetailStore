package com.springboot.Order_Service.Entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;



@Entity
public class OrderEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int orderId;
	
	@NotNull(message="customerId is required")
	@Positive(message = "customerId must be positive number")
	private int customerId;
	
	

	@OneToMany(cascade=CascadeType.ALL)
	@JsonManagedReference
	private List<OrderLineItem> orderLineItem;

	
	public OrderEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderEntity(int orderId,int customerId, List<OrderLineItem> orderLineItem) {
		super();
		this.orderId = orderId;
		this.customerId=customerId;
		this.orderLineItem = orderLineItem;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public List<OrderLineItem> getOrderLineItem() {
		return orderLineItem;
	}

	public void  setOrderLineItem(List<OrderLineItem> orderLineItem) {
		this.orderLineItem = orderLineItem;
	}
	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	

}
