package com.springboot.Order_Service.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.springboot.Order_Service.Entity.OrderEntity;
import com.springboot.Order_Service.Entity.OrderLineItem;
import com.springboot.Order_Service.Service.OrderService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/order/")
@CrossOrigin("*")
public class OrderController {

	@Autowired
	private OrderService orderServ;

	@PostMapping("placeOrder")
	public ResponseEntity<OrderEntity> placeOrder(@Valid @RequestBody OrderEntity order) {
		return new ResponseEntity<>(orderServ.placeOrder(order), HttpStatus.OK);
	}

	@PostMapping("placeOrderTo/{orderId}")
	public ResponseEntity<Object> placeOrderTo(@PathVariable int orderId, @Valid @RequestBody OrderLineItem lineItem) {
		orderServ.placeOrderTo(orderId, lineItem);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@GetMapping("getOrder")
	public List<OrderEntity> getOrder() {
		return orderServ.getOrder();
	}

	@DeleteMapping("deleteOrder/{orderId}")
	public ResponseEntity<Object> deleteOrder(@PathVariable int orderId) {
		orderServ.deleteOrder(orderId);
		return ResponseEntity.status(HttpStatus.OK).build();
	}
//	@GetMapping("searchByProductId/{productId}")
//	public ResponseEntity<Object> searchByProduct()
//	{
//		orderServ.searchByProductId();
//		return ResponseEntity.status(HttpStatus.CREATED).build();
//	}
}
