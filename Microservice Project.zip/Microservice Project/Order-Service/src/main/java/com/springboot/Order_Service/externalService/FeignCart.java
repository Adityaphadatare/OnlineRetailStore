package com.springboot.Order_Service.externalService;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("CART/api/cart/")
public interface FeignCart {

	@GetMapping("getCartIdByCustomerId/{customerId}")
	int getCartIdByCustomerId(@PathVariable int customerId);
	
	@DeleteMapping("emptyCart/{cartId}")
	void emptyCart(@PathVariable int cartId);
}