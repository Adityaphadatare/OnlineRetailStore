package com.springboot.Order_Service.Service;

import java.util.List;

import com.springboot.Order_Service.Entity.OrderEntity;
import com.springboot.Order_Service.Entity.OrderLineItem;

public interface OrderService {
	OrderEntity placeOrder(OrderEntity order);

	void placeOrderTo(int orderId, OrderLineItem lineItem);

	List<OrderEntity> getOrder();

	void deleteOrder(int orderId);

}
