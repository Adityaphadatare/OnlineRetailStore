package com.springboot.Order_Service.Service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.Order_Service.Entity.OrderEntity;
import com.springboot.Order_Service.Entity.OrderLineItem;
import com.springboot.Order_Service.Repository.OrderRepository;
import com.springboot.Order_Service.externalService.FeignCart;
import com.springboot.Order_Service.externalService.FeignInventory;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepository orderRepo;
//	@Autowired
//	private WebClient webClient;
	@Autowired
	private FeignInventory feignInv;
	@Autowired
	private FeignCart feignCart;

	@Override
	public OrderEntity placeOrder(OrderEntity order) {
		OrderEntity o = new OrderEntity();
		o.setOrderLineItem(order.getOrderLineItem());
		int cartId = (int) feignCart.getCartIdByCustomerId(order.getCustomerId());
		System.out.println(cartId);
		feignCart.emptyCart(cartId);
		List<Integer> productIdList = order.getOrderLineItem().stream().map(inventory -> inventory.getId()).toList();
		List<Integer> inte = feignInv.isInStock(productIdList);

		List<OrderLineItem> olList = o.getOrderLineItem();
		List<OrderLineItem> result = new ArrayList<OrderLineItem>();
		for (int i = 0; i < olList.size(); i++) {
			for (int j = 0; j < inte.size(); j++) {
				if (olList.get(i).getProductId() == inte.get(i)) {
					olList.get(i).setQuantity(1);
					result.add(olList.get(i));
				}
			}
		}
		o.setOrderLineItem(result);

		return orderRepo.save(order);
	}

//		InventoryResponse[] inventoryResponseArray=webClient.get()
//				.uri("http://localhost:8083/api/inventory", 
//						uriBuilder -> uriBuilder.queryParam("productId",productIdList).build())
//				.retrieve()
//				.bodyToMono(InventoryResponse[].class)
//				.block(); 
//		
//		Arrays.stream(inventoryResponseArray).map(i -> i.getI).toList();

	@Override
	public void placeOrderTo(int orderId, OrderLineItem lineItem) {
		OrderEntity pre = orderRepo.findById(orderId).get();
		List<OrderLineItem> li = pre.getOrderLineItem();
		li.add(lineItem);
		pre.setOrderLineItem(li);
		orderRepo.save(pre);
		System.out.println("from service");

	}

	@Override
	public List<OrderEntity> getOrder() {
		return orderRepo.findAll();
	}

	@Override
	public void deleteOrder(int orderId) {
		orderRepo.deleteById(orderId);
	}
}
