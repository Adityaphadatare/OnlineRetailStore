package com.springboot.Order_Service.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Entity
public class OrderLineItem {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@NotNull(message = "Product Id required")
	@Positive(message = "productId must be positive number")
	private int productId;
	
	@NotNull(message = "price required")
	@Positive(message = "price must be positive number")
	private int price;
	
	@NotNull(message = "quantity required")
	@Positive(message = "quantity must be positive number")
	private int quantity;
	
	@ManyToOne
	@JsonBackReference
	private OrderEntity orderEntity;
	

	public OrderLineItem() {
		super();
	}

	public OrderLineItem(int id, int productId, int price, int quantity,OrderEntity orderEntity) {
		super();
		this.id = id;
		this.productId = productId;
		this.price = price;
		this.quantity = quantity;
		this.orderEntity=orderEntity;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public OrderEntity getOrderEntity() {
		return orderEntity;
	}

	public void setOrderEntity(OrderEntity orderEntity) {
		this.orderEntity = orderEntity;
	}
}
