package com.springboot.Inventory.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.Inventory.Entity.InvProduct;
import com.springboot.Inventory.Service.InventoryService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/inventory/")
@CrossOrigin("*")
public class InventoryContoller {

	@Autowired
	private InventoryService invServ;
	
	@GetMapping("checkOrder")
	public List<Integer> isInStock(@Valid @RequestParam List<Integer> productId)
	{
		System.out.println(productId);
		return invServ.isInStock(productId);
	}
	
	
	@PostMapping("addInventory")
	public ResponseEntity<Object> addInventory(@Valid @RequestBody InvProduct product)
	{
		invServ.addInventory(product);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}
	
	@PutMapping("updateInventory/{productId}")
	public ResponseEntity<Object> updateInventory(@PathVariable int productId, @Valid @RequestBody InvProduct product)
	{
		invServ.updateInventory(productId, product);
		return ResponseEntity.status(HttpStatus.OK).build();
	}
	
	@DeleteMapping("deleteInventory/{productId}")
	public ResponseEntity<Object> deleteInventory(@PathVariable int productId)
	{
		invServ.deleteInventory(productId);
		return ResponseEntity.status(HttpStatus.OK).build();
	}
	
	@GetMapping("searchInventory/{productId}")
	public ResponseEntity<InvProduct> searchInventory(@PathVariable int productId)
	{
		invServ.searchInventory(productId);
		return new ResponseEntity<>(invServ.searchInventory(productId), HttpStatus.OK);
	}

	
	
}
