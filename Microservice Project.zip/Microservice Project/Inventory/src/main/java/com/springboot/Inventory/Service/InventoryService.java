package com.springboot.Inventory.Service;

import java.util.List;

import com.springboot.Inventory.Entity.InvProduct;

public interface InventoryService {

	List<Integer> isInStock(List<Integer> productId);

	void addInventory(InvProduct product);

	void updateInventory(int id, InvProduct product);

	void deleteInventory(int id);

	InvProduct searchInventory(int id);

}
