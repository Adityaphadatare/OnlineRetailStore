package com.springboot.Inventory.Service;

public class InventoryResponse {

	private int inventoryId;
	private int productId;

	private boolean isInStock;

	public InventoryResponse() {
		super();
	}

	public InventoryResponse(int inventoryId, int productId, boolean isInStock) {
		super();
		this.inventoryId = inventoryId;
		this.productId = productId;
		this.isInStock = isInStock;
	}

	public int getInventoryId() {
		return inventoryId;
	}

	public void setInventoryId(int inventoryId) {
		this.inventoryId = inventoryId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public boolean isInStock() {
		return isInStock;
	}

	public void setInStock(boolean isInStock) {
		this.isInStock = isInStock;
	}

}
