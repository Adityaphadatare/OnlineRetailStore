package com.springboot.Inventory.Service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.Inventory.Entity.InvProduct;
import com.springboot.Inventory.Repository.InventoryRepo;

@Service
public class InventoryServiceImpl implements InventoryService {

	@Autowired
	private InventoryRepo invRepo;

	public List<Integer> isInStock(List<Integer> productId) {

//		return invRepo.findByProductIdIn(productId).stream().filter(inv -> inv.getQuantity()>0).toList();
		List<InvProduct> pro = invRepo.findByProductIdIn(productId);
		List<Integer> inte = pro.stream().map(inventory -> inventory.getProductId()).toList();
		return inte;

	}

	public void addInventory(InvProduct product) {
		invRepo.save(product);
	}

	public void updateInventory(int id, InvProduct product) {

		InvProduct prod = invRepo.findById(id).get();
		if (prod != null) {
			prod.setProductId(product.getProductId());
			prod.setQuantity(product.getQuantity());
			invRepo.save(prod);
		}
	}

	public void deleteInventory(int id) {
		InvProduct invPro = invRepo.findById(id).get();
		if (invPro != null)
			invRepo.deleteById(id);

	}

	public InvProduct searchInventory(int id) {
		InvProduct invpro = invRepo.findById(id).get();
		return invpro;
	}
}
