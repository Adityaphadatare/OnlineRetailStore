package com.springboot.Inventory.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.Inventory.Entity.InvProduct;

@Repository
public interface InventoryRepo extends JpaRepository<InvProduct, Integer> {

	List<InvProduct> findByProductIdIn(List<Integer> productId);

}
