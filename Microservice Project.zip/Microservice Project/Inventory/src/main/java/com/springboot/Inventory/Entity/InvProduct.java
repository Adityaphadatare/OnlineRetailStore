package com.springboot.Inventory.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

@Entity
public class InvProduct {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int inventoryId;
	
	@NotNull(message="ProductId is required")
	@Positive(message = "productId must be positive number")
	private int productId;
	
	@NotNull(message="quantity is required")
	@Positive(message = "quantity must be positive number")
	private int quantity;
	
	public InvProduct() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvProduct(int productId, int quantity) {
		super();
		this.productId = productId;
		this.quantity = quantity;
	}

	public int getInventoryId() {
		return inventoryId;
	}

	public void setInventoryId(int inventoryId) {
		this.inventoryId = inventoryId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "InvProduct [inventoryId=" + inventoryId + ", productId=" + productId + ", quantity=" + quantity + "]";
	}
	
	
	

}
