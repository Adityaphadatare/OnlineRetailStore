package com.springboot.customerPart.Entity;

import java.util.List;


public class Cart {

	private int cartId;
	private int customerId;
	private List<LineItem> lineItem;
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Cart(int cartId, int customerId, List<LineItem> lineItem) {
		super();
		this.cartId = cartId;
		this.customerId = customerId;
		this.lineItem = lineItem;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public List<LineItem> getLineItem() {
		return lineItem;
	}
	public void setLineItem(List<LineItem> lineItem) {
		this.lineItem = lineItem;
	}
	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", customerId=" + customerId + ", lineItem=" + lineItem + "]";
	}
	
	
	
}
