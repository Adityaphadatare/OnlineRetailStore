package com.springboot.customerPart.Service;

import java.util.List;

import com.springboot.customerPart.Entity.Address;
import com.springboot.customerPart.Entity.Customer;

public interface CustomerService {

	int addCustomer(Customer customer);

	void deleteCustomer(int customerId);

	void updateCustomer(int customerId, Customer customer);

	Customer searchCustomer(int id);

	void updateAddress(int customerId, Address address);

	void deleteAddress(int customerId);

	List<Customer> getAllCustomers();

}
