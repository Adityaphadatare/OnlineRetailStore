package com.springboot.customerPart.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.customerPart.Entity.Address;
import com.springboot.customerPart.Entity.Cart;
import com.springboot.customerPart.Entity.Customer;
import com.springboot.customerPart.Repository.CustomerRepo;
import com.springboot.customerPart.externalService.FeignCart;

@Service
public class CustermerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepo customerRepo;

	@Autowired
	private FeignCart feignCart;

	@Override
	public int addCustomer(Customer customer) {
		// so cart get to bind with different customerId

		customerRepo.save(customer);
		Cart cart = new Cart();
		cart.setCustomerId(customer.getCustomerId());// getting customerId of parameter customer
		System.out.println("In CustomerService ");
		return feignCart.addCart(cart);
	}

	@Override
	public void deleteCustomer(int customerId) {
		Customer customer = searchCustomer(customerId);
		if (customer != null) {
			customerRepo.deleteById(customerId);
		}

	}

	@Override
	public void updateCustomer(int customerId, Customer customer) {

		Customer cust = customerRepo.findById(customerId).get();
		if (cust != null) {
			cust.setCustomerName(customer.getCustomerName());
			cust.setEmailId(customer.getEmailId());
			cust.setAddress(customer.getAddress());
			customerRepo.save(cust);
		}
	}

	@Override
	public Customer searchCustomer(int id) {
		Optional<Customer> opt = customerRepo.findById(id);
		if (opt.isEmpty()) {
			return null;
		}
		return opt.get();
	}

	@Override
	public void updateAddress(int customerId, Address address) {
		Customer cust = customerRepo.findById(customerId).get();

		if (cust != null) {
//			Address addr=cust.getAddress();
//			addressRepo.deleteById(addr.getId());
			cust.setAddress(address);
			customerRepo.save(cust);
		}

	}

	@Override
	public void deleteAddress(int customerId) {
		Customer cust = customerRepo.findById(customerId).get();
		if (cust != null) {
			Address addr = cust.getAddress();
			addr.setCity(null);
			addr.setDoorNo(0);
			addr.setPincode(0);
			addr.setStreet(null);
			updateAddress(customerId, addr);

		}
	}

	@Override
	public List<Customer> getAllCustomers() {

		return customerRepo.findAll();
	}
}
