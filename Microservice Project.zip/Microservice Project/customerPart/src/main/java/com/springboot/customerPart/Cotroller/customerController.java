package com.springboot.customerPart.Cotroller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.springboot.customerPart.Entity.Address;
import com.springboot.customerPart.Entity.Customer;
import com.springboot.customerPart.Service.CustomerService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/customer/")
@CrossOrigin("*")
public class customerController {

	
	@Autowired
	private CustomerService customerService;
	
	@CircuitBreaker(name = "cartBreaker", fallbackMethod="cartBreaker")
	@PostMapping("addCustomer")
	public ResponseEntity<Integer> addCustomer(@Valid @RequestBody Customer customer) {
		
//		Cart c= customerService.addCustomer(customer);
		int i=customerService.addCustomer(customer);
		System.out.println("cart id "+i);
		return new ResponseEntity<Integer>(i, HttpStatus.OK);
//		return ResponseEntity.status(HttpStatus.OK).build();
	}
// creating fallback for cart service
	public ResponseEntity<Integer> cartBreaker(Customer customer, Exception ex)
	{
//		Customer c =new Customer(0, "dummy", "dummy@gmail.com", null);
		return new ResponseEntity<Integer>(0, HttpStatus.OK);
	}
	
	 
	@DeleteMapping("deleteCustomer/{customerId}")
	public ResponseEntity<Object> deleteCustomer(@PathVariable int customerId)
	{
		customerService.deleteCustomer(customerId);
		
		return ResponseEntity.status(HttpStatus.OK).build();
	}
	
	@PutMapping("updateCustomer/{customerId}")
	public ResponseEntity<Object> updateCustomer(@PathVariable int customerId, @Valid @RequestBody Customer customer)
	{
		customerService.updateCustomer(customerId, customer);
		return ResponseEntity.status(HttpStatus.OK).build();
	}
	@GetMapping("searchCustomer/{customerId}")
	public ResponseEntity<Customer> searchCustomer(@PathVariable int customerId)
	{
		Customer customer=customerService.searchCustomer(customerId);
		if(customer==null)
			throw new ResponseStatusException(HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<Customer>(customer, HttpStatus.OK);
	}
	@GetMapping("getAllCustomers")
	public ResponseEntity<List<Customer>> getAllCustomers()
	{	
		return new ResponseEntity<>(customerService.getAllCustomers(), HttpStatus.OK);
	}
	
//---------------------------------Address Part----------------------
	@PutMapping("updateAddress/{customerId}")
	public ResponseEntity<Object> updateAddress(@PathVariable int customerId, @Valid @RequestBody Address address)
	{
		customerService.updateAddress(customerId, address);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}
	@DeleteMapping("deleteAddress/{customerId}")
	public ResponseEntity<Object> deleteAddress(@PathVariable int customerId)
	{
		customerService.deleteAddress(customerId);
		return ResponseEntity.status(HttpStatus.OK).build();
	}
	
}
