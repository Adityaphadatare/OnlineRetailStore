package com.springboot.customerPart.externalService;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.springboot.customerPart.Entity.Cart;

@FeignClient("CART/api/cart/")
public interface FeignCart {
	
	@PostMapping("addCart")
	int addCart(@RequestBody Cart cart);
	
	

	
}
