package com.springboot.customerPart.Entity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

@Entity
public class Address implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@NotNull(message = "doorNo is required")
	@Positive(message = "doorNo must be positive number")
	@Size(min = 1, max = 5, message = "Enter valid doorNo")
	private int doorNo;

	@NotEmpty(message = "Enter street properly")
	@Size(min = 3, max = 30, message = "Enter valid street")
	private String street;
	
	@NotEmpty(message = "Enter city properly")
	@Size(min = 3, max = 10, message = "Enter valid city")
	private String city;
	
	@NotNull(message = "pincode is required")
	@Size(min = 3, max = 30, message = "Enter valid pincode")
	@Positive(message = "pincode must be positive number")
	private int pincode;

	@OneToOne
	@JsonBackReference
	private Customer customer;

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Address(int id, int doorNo, String street, String city, int pincode) {
		super();
		this.id = id;
		this.doorNo = doorNo;
		this.street = street;
		this.city = city;
		this.pincode = pincode;
	}

	public int getId() {
		return id;
	}

	public int getDoorNo() {
		return doorNo;
	}

	public void setDoorNo(int doorNo) {
		this.doorNo = doorNo;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

}
