package com.springboot.customerPart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerPartApplicationTests {

	@Test
	void contextLoads() {
	}

}
