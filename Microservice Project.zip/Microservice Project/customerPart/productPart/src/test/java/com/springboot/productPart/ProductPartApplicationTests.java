package com.springboot.productPart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductPartApplicationTests {

	@Test
	void contextLoads() {
	}

}
