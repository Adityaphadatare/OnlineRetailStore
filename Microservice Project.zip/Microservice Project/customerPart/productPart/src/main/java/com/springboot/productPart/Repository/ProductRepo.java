package com.springboot.productPart.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.productPart.Entity.Product;

public interface ProductRepo extends JpaRepository<Product, Integer>{

	
}
