package com.springboot.productPart.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.productPart.Entity.Product;
import com.springboot.productPart.Repository.ProductRepo;

@Service
public class ProductService {
	
//	static
//	{
//		Product product1 = new Product(1,"Samsung TV","TV",30000);
//		Product product2 = new Product(2,"Oppo","Android Mobile",18000);
//		Product product3 = new Product(3,"Lenovo","Android Tab",22000);
//		Product product4 = new Product(4,"boAt","Neckband Bluetooth",1500);
//		Product product5 = new Product(5,"Noise","Smart Watch",8000);
//
//	}
	
	@Autowired
	private ProductRepo productRepo;
	

	public void addProduct(Product product) {
			productRepo.save(product);
	}

	public void deleteProduct(int id) {
		Product product=productRepo.findById(id).get();
		if(product!=null)
			productRepo.deleteById(id);
		
	}

	public void updateProduct(int id, Product product) {
		
		Product prod=productRepo.findById(id).get();
		if(prod!=null) {
			prod.setProductName(product.getProductName());
			prod.setProductDescription(product.getProductDescription());
			prod.setProductPrice(product.getProductPrice());
			productRepo.save(prod);
		}
		
		
		
	}

	public Product searchProduct(int id) {
		Product product=productRepo.findById(id).get();
			return product;
	}


}
