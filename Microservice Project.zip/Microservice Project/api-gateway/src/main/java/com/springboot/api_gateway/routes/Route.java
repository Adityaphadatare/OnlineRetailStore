package com.springboot.api_gateway.routes;

import org.springframework.cloud.gateway.server.mvc.handler.GatewayRouterFunctions;
import org.springframework.cloud.gateway.server.mvc.handler.HandlerFunctions;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.function.RequestPredicates;
import org.springframework.web.servlet.function.RouterFunction;
import org.springframework.web.servlet.function.ServerResponse;

//@Configuration
public class Route {

//	@Bean
//	public RouterFunction<ServerResponse> productService()
//	{
//		return GatewayRouterFunctions.route("PRODUCT-MICROSERVICE")
//				.route(RequestPredicates.path("/api/product/**"), HandlerFunctions.http("http://localhost:8080"))
//				.build();
//	}
//	
//	@Bean
//	public RouterFunction<ServerResponse> customerPartService()
//	{
//		return GatewayRouterFunctions.route("customerPart")
//				.route(RequestPredicates.path("/api/customer/**"), HandlerFunctions.http("http://localhost:8081"))
//				.build();
//	}
//	@Bean
//	public RouterFunction<ServerResponse> inventoryService()
//	{
//		return GatewayRouterFunctions.route("Inventory")
//				.route(RequestPredicates.path("/api/inventory/**"), HandlerFunctions.http("http://localhost:8083"))
//				.build();
//	}
//	@Bean
//	public RouterFunction<ServerResponse> cartService()
//	{
//		return GatewayRouterFunctions.route("Cart")
//				.route(RequestPredicates.path("/api/cart/**"), HandlerFunctions.http("http://localhost:8084"))
//				.build();
//	}
//	@Bean
//	public RouterFunction<ServerResponse> orderServiceService()
//	{
//		return GatewayRouterFunctions.route("Order-Service")
//				.route(RequestPredicates.path("/api/order/**"), HandlerFunctions.http("http://localhost:8085"))
//				.build();
//	}
//	@Bean
//	public RouterFunction<ServerResponse> eurekaService()
//	{
//		return GatewayRouterFunctions.route("discovery-server")
//				.route(RequestPredicates.path("/"), HandlerFunctions.http("http://localhost:8086"))
//				.build();
//	}
	
}
