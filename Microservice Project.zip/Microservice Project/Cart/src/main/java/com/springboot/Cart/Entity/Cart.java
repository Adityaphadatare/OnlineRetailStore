package com.springboot.Cart.Entity;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Entity
public class Cart implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cartId;
	
	@NotNull(message = "CustomerId required")
	@Positive(message = "customerId must be positive number")
	private int customerId;
	
	@OneToMany(cascade=CascadeType.ALL, mappedBy="cart", orphanRemoval=true)
	@JsonManagedReference
	private List<LineItem> lineItem;

	public Cart() {
		super();
	}

	public Cart(int cartId, int customerId, List<LineItem> lineItem) {
		super();
		this.cartId = cartId;
		this.customerId = customerId;
		this.lineItem = lineItem;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public List<LineItem> getLineItem() {
		return lineItem;
	}

	public void setLineItem(List<LineItem> lineItem) {
		this.lineItem = lineItem;
	}
	public LineItem addLineItem(LineItem lineItem)
	{
		this.lineItem.add(lineItem);
		return lineItem;
	}
	public void removeLineItem(LineItem lineItem)
	{
		this.lineItem.remove(lineItem);
	}

}
