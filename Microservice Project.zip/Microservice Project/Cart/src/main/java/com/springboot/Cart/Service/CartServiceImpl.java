package com.springboot.Cart.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.Cart.Entity.Cart;
import com.springboot.Cart.Entity.LineItem;
import com.springboot.Cart.Repository.CartRepo;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	private CartRepo cartRepo;

	@Override
	public Cart addCart(Cart cart) {
		return cartRepo.save(cart);
	}

	@Override
	public Cart updateCart(int cartId, Cart cart) {

		Cart c = searchCart(cartId);
		if(c!=null) {
			cart.setCartId(cartId);
			return cartRepo.save(cart);
		}
		return null;
	}

	@Override
	public List<Cart> getAllCart() {
		return cartRepo.findAll();
	}

	@Override
	public void emptyCart(int cartId) {

		Cart c = searchCart(cartId);

		if (c != null) {
			c.setCartId(cartId);
			List<LineItem> lt = c.getLineItem();
			lt.clear();
			cartRepo.save(c);
		}
	}

	@Override
	public Cart searchCart(int cartId) {

		Optional<Cart> c = cartRepo.findById(cartId);
		return c.orElse(null);

	}

	@Override
	public Cart searchCustomerCart(int customerId) {
		return cartRepo.findByCustomerId(customerId);
	}

//-------------------------------------LineItem----------------------------
	@Override
	public void addLineItem(int cartId, LineItem lineItem) {

//		Cart c=cartRepo.findById(cartId).get();
//		lineItem.setCart(c);
//		c.setCartId(cartId);
//		c.getLineItem().add(lineItem);
//		cartRepo.save(c);
		Cart c = cartRepo.findById(cartId).get();
		List<LineItem> listItem = c.getLineItem();
		for (int i = 0; i < listItem.size(); i++) {
			if (listItem.get(i).getProductId() == lineItem.getProductId()) {
				listItem.get(i).setQuantity(listItem.get(i).getQuantity() + 1);
				c.setCartId(cartId);
				c.setLineItem(listItem);
				cartRepo.save(c);
				return;
			}
		}
		lineItem.setQuantity(1);
		lineItem.setCart(c);
		c.setCartId(cartId);
		listItem.add(lineItem);
		c.setLineItem(listItem);
		cartRepo.save(c);

	}

//	public void updateLineItem(int cartId, int itemId, LineItem lineItem) {
//		
//		LineItem lt=searchLineItem(cartId, itemId);
//		lt.setPrice(lineItem.getPrice());
//		lt.setProductId(lineItem.getProductId());
//		lt.setProductName(lineItem.getProductName());
//		lt.setQuantity(lineItem.getQuantity());
//		Cart c= cartRepo.findById(cartId).get();
//		List<LineItem> l
//		updateCart(cartId, )
////		lineItemRepo.save(lt);------------------------------------------
//		
//	}
	@Override
	public void deleteLineItem(int cartId, int lineItemId) {

		LineItem lt = searchLineItem(cartId, lineItemId);

		Cart c = cartRepo.findById(cartId).get();
		List<LineItem> listLt = c.getLineItem();
		boolean anyMatch = listLt.stream().anyMatch(s -> s.getProductId() == lt.getProductId());
		System.out.println(anyMatch);

		if (anyMatch) {
//			listLt.remove(lt);
//			System.out.println(listLt);
			c.setCartId(cartId);
			c.removeLineItem(lt);
//			c.setLineItem(listLt);
			cartRepo.save(c);

		}
	}

//---------------------------------------------------------------OK-----
	@Override
	public LineItem searchLineItem(int cartId, int itemId) {
		Cart c = cartRepo.findById(cartId).get();
		LineItem lt = c.getLineItem().stream().filter(l -> itemId == (l.getItemId())).findAny().orElse(null);
		System.out.println(lt);
		return lt;
	}

	@Override
	public Cart getCartByCustomer(int customerId) {

		return cartRepo.findByCustomerId(customerId);
	}

	@Override
	public int getCartIdByCustomerId(int customerId) {
		return cartRepo.findByCustomerId(customerId).getCartId();
	}

}
