package com.springboot.Cart.Service;

import java.util.List;

import com.springboot.Cart.Entity.Cart;
import com.springboot.Cart.Entity.LineItem;

public interface CartService {

	Cart addCart(Cart cart);

	Cart updateCart(int cartId, Cart cart);

	List<Cart> getAllCart();

	void emptyCart(int cartId);

	Cart searchCart(int cartId);

	Cart searchCustomerCart(int customerId);

	void addLineItem(int cartId, LineItem lineItem);

	void deleteLineItem(int cartId, int lineItemId);

	LineItem searchLineItem(int cartId, int itemId);

	Cart getCartByCustomer(int customerId);

	int getCartIdByCustomerId(int customerId);

}
