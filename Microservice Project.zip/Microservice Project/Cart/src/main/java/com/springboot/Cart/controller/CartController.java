package com.springboot.Cart.controller;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.Cart.Entity.Cart;
import com.springboot.Cart.Entity.LineItem;
import com.springboot.Cart.Exception.CartNotFoundException;
import com.springboot.Cart.Service.CartService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/cart/")
@CrossOrigin("*")
public class CartController {

	private static final Logger logger = LoggerFactory.getLogger(CartController.class);

	@Autowired
	private CartService cartServ;

	@PostMapping("addCart")
	public ResponseEntity<Integer> addCart(@Valid @RequestBody Cart cart) {
		LocalDateTime startTime = LocalDateTime.now();
		Cart c = cartServ.addCart(cart);
		LocalDateTime endTime = LocalDateTime.now();
		Duration timeTaken = Duration.between(startTime, endTime);
		logger.info("Time taken for addCart(): {}", timeTaken);
		return new ResponseEntity<>(c.getCartId(), HttpStatus.OK);
	}

	@PutMapping("updateCart/{cartId}")
	public ResponseEntity<Object> updateCart(@PathVariable int cartId, @Valid @RequestBody Cart cart)
			throws CartNotFoundException {
		LocalDateTime startTime = LocalDateTime.now();
		Cart c = cartServ.updateCart(cartId, cart);

		LocalDateTime endTime = LocalDateTime.now();
		Duration timeTaken = Duration.between(startTime, endTime);
		logger.info("Time taken for updateCart(): {}", timeTaken);
		if (c != null)
			return new ResponseEntity<>(c, HttpStatus.OK); // Return updated cart
		else
			throw new CartNotFoundException("Cart Object not Found with Given Id"); // Handle not found
	}

	@DeleteMapping("emptyCart/{cartId}")
	public ResponseEntity<Object> emptyCart(@PathVariable int cartId) {
		LocalDateTime startTime = LocalDateTime.now();
		cartServ.emptyCart(cartId);
		LocalDateTime endTime = LocalDateTime.now();
		Duration timeTaken = Duration.between(startTime, endTime);
		logger.info("Time taken for emptyCart(): {}", timeTaken);
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@GetMapping("searchCart/{cartId}")
	public ResponseEntity<Cart> searchCart(@PathVariable int cartId) throws CartNotFoundException {
		LocalDateTime startTime = LocalDateTime.now();
		Cart c = cartServ.searchCart(cartId);
		LocalDateTime endTime = LocalDateTime.now();
		Duration timeTaken = Duration.between(startTime, endTime);
		logger.info("Time taken for searchCart(): {}", timeTaken);
		if (c != null)
			return new ResponseEntity<>(c, HttpStatus.OK); // Return found cart
		else
			throw new CartNotFoundException("Cart Object not Found with Given Id"); // Handle not found

	}

	@GetMapping("searchCustomerCart/{customerId}")
	public ResponseEntity<Cart> searchCustomerCart(@PathVariable int customerId) {
		LocalDateTime startTime = LocalDateTime.now();
		Cart c = cartServ.searchCustomerCart(customerId);
		LocalDateTime endTime = LocalDateTime.now();
		Duration timeTaken = Duration.between(startTime, endTime);
		logger.info("Time taken for searchCustomerCart(): {}", timeTaken);
		return new ResponseEntity<>(c, HttpStatus.OK);

	}

	@GetMapping("getAllCart")
	public ResponseEntity<List<Cart>> getAllCart() {
		return new ResponseEntity<>(cartServ.getAllCart(), HttpStatus.OK);
	}

	@GetMapping("getCartByCustomerId/{customerId}")
	public ResponseEntity<Cart> getCartByCustomerId(@PathVariable int customerId) {
		return new ResponseEntity<>(cartServ.getCartByCustomer(customerId), HttpStatus.OK);
	}

	@GetMapping("getCartIdByCustomerId/{customerId}")
	public ResponseEntity<Integer> getCartIdByCustomerId(@PathVariable int customerId) {
		return new ResponseEntity<>(cartServ.getCartIdByCustomerId(customerId), HttpStatus.OK);
	}

//----------------------------------LineItem------------------------------------------

	@PostMapping("addLineItem/{cartId}")
	public ResponseEntity<Object> addLineItem(@PathVariable int cartId, @Valid @RequestBody LineItem lineItem) {
		LocalDateTime startTime = LocalDateTime.now();
		cartServ.addLineItem(cartId, lineItem);
		LocalDateTime endTime = LocalDateTime.now();
		Duration timeTaken = Duration.between(startTime, endTime);
		logger.info("Time taken for addLineItem(): {}", timeTaken);
		return ResponseEntity.status(HttpStatus.OK).build();

	}

//	@PutMapping("updateLineItem/{cartId}/{itemId}")
//	public ResponseEntity<Object> updateLineItem(@PathVariable int cartId, @PathVariable int itemId, @RequestBody LineItem lineItem)
//	{
//		cartServ.updateLineItem(cartId,itemId, lineItem);
//		return ResponseEntity.status(HttpStatus.OK).build();
//
//	}
	@DeleteMapping("deleteLineItem/{cartId}/{itemId}")
	public ResponseEntity<Object> deleteLineItem(@PathVariable int cartId, @PathVariable int itemId) {
		LocalDateTime startTime = LocalDateTime.now();
		cartServ.deleteLineItem(cartId, itemId);
		LocalDateTime endTime = LocalDateTime.now();
		Duration timeTaken = Duration.between(startTime, endTime);
		logger.info("Time taken for deleteLineItem(): {}", timeTaken);
		return ResponseEntity.status(HttpStatus.OK).build();

	}

	@GetMapping("searchLintItem/{cartId}/{itemId}")
	public ResponseEntity<LineItem> searchLineItem(@PathVariable int cartId, @PathVariable int itemId) {
		LocalDateTime startTime = LocalDateTime.now();
		LineItem lt = cartServ.searchLineItem(cartId, itemId);
		LocalDateTime endTime = LocalDateTime.now();
		Duration timeTaken = Duration.between(startTime, endTime);
		logger.info("Time taken for searchLineItem(): {}", timeTaken);
		return new ResponseEntity<>(lt, HttpStatus.OK);

	}
}
