package com.springboot.Cart.Entity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

@Entity
public class LineItem implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int itemId;

	@NotNull(message = "Product Id required")
	@Positive(message = "productId must be positive number")
	private int productId;
	
	@NotBlank(message = "Product Name required")
	private String productName;
	
	@NotNull(message = "Quantity required")
	@Positive(message = "Quantity must be positive number")
	private int quantity;
	
	@Positive(message = "price must be positive number")
	@NotNull(message = "Product price required")
	private int productPrice;

	@ManyToOne
	@JsonBackReference
	private Cart cart;

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public LineItem() {
		super();
	}

//	public LineItem(int itemId, int productId, String productName, int quantity, int price) {
//		super();
//		this.itemId = itemId;
//		this.productId = productId;
//		this.productName = productName;
//		this.quantity = quantity;
//		this.price = price;
//	}

	public int getItemId() {
		return itemId;
	}

	public LineItem(int itemId, int productId, String productName, int quantity, int productPrice, Cart cart) {
		super();
		this.itemId = itemId;
		this.productId = productId;
		this.productName = productName;
		this.quantity = quantity;
		this.productPrice = productPrice;
		this.cart = cart;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	@Override
	public String toString() {
		return "LineItem [itemId=" + itemId + ", productId=" + productId + ", productName=" + productName
				+ ", quantity=" + quantity + ", productPrice=" + productPrice + "]";
	}

}
