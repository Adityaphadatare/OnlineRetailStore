package com.springboot.Cart.Exception;

/**
 * Custom exception class to indicate that a cart was not found. Extends the
 * Exception class to provide specific error handling for cases where a cart
 * is unavailable.
 */
public class CartNotFoundException extends Exception {

	private static final long serialVersionUID = 1L; // Serialization ID
	String msg; // Exception message

	/**
	 * Constructs a CartNotFoundException with the specified message.
	 *
	 * @param msg The detail message for the exception
	 */
	public CartNotFoundException(String msg) {
		super(msg); // Pass the message to the superclass
	}

}
