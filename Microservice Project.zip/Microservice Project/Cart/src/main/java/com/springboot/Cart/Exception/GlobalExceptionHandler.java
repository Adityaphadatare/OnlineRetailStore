package com.springboot.Cart.Exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.TransactionSystemException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * Global exception handler for handling various exceptions across the
 * application. This class captures exceptions thrown by the controllers and
 * provides custom responses.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

	/**
	 * Handles MethodArgumentNotValidException and returns a 405 Method Not Allowed
	 * response.
	 *
	 * @param e the MethodArgumentNotValidException thrown
	 * @return a ResponseEntity containing the exception message and HTTP status 405
	 */
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException e) {
		Map<String, String> map = new HashMap<>();
		e.getBindingResult().getAllErrors().forEach(error -> {
			String field1 = ((FieldError) error).getField();
			String field2 = error.getDefaultMessage();
			map.put(field1, field2);
		});
		return new ResponseEntity<>(map, HttpStatus.NOT_FOUND);
	}

	/**
	 * Handles HttpRequestMethodNotSupportedException and returns a 405 Method Not
	 * Allowed response.
	 *
	 * @param e the HttpRequestMethodNotSupportedException thrown
	 * @return a ResponseEntity containing the exception message and HTTP status 405
	 */
	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	public ResponseEntity<String> handlerHttpRequestMethodNotSupportedException(
			HttpRequestMethodNotSupportedException e) {
		return new ResponseEntity<>(e.getMessage(), HttpStatus.METHOD_NOT_ALLOWED);
	}

	/**
	 * Handles CartNotFoundException and returns a 404 Not Found response.
	 *
	 * @param e the CartNotFoundException thrown
	 * @return a ResponseEntity containing the exception message and HTTP status 404
	 */
	@ExceptionHandler(CartNotFoundException.class)
	public ResponseEntity<String> handlerProductNotFoundException(CartNotFoundException e) {
		return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(TransactionSystemException.class)
	public ResponseEntity<String> handlerProductNotFoundException(TransactionSystemException e) {
		return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
	}

}
