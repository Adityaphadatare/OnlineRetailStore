package com.springboot.Product_Microservice.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.springboot.Product_Microservice.Entity.Product;
import com.springboot.Product_Microservice.Exception.ProductNotFoundException;
import com.springboot.Product_Microservice.Service.ProductService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/product/")
@CrossOrigin("*")
public class ProductController {

	@Autowired
	private ProductService productService;

	@PostMapping("addProduct")
	public ResponseEntity<Object> addProduct(@Valid @RequestBody Product product) {
		productService.addProduct(product);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@DeleteMapping("deleteProduct/{id}")
	public ResponseEntity<Object> deleteProduct(@PathVariable int id) {
		productService.deleteProduct(id);
		return ResponseEntity.status(HttpStatus.OK).build();

	}

	@PutMapping("updateProduct/{id}")
	public ResponseEntity<Product> updateProduct(@PathVariable int id, @Valid @RequestBody Product product)
			throws ProductNotFoundException {
		Product pro = productService.updateProduct(id, product);
		if (pro != null)
			return new ResponseEntity<>(product, HttpStatus.OK);
		else
			throw new ProductNotFoundException("Please choose right ProductId to update");

	}

	@GetMapping("searchProduct/{id}")
	public ResponseEntity<Product> searchProduct(@PathVariable int id) throws ProductNotFoundException {
		Product product = productService.searchProduct(id);
		if (product != null) {
			return new ResponseEntity<>(product, HttpStatus.OK);
		} else {
			throw new ProductNotFoundException("Product object not found with given ID");
		}

	}

	@GetMapping("getAllProducts")
	public ResponseEntity<List<Product>> getAllProductsProduct() {
		List<Product> productList = productService.getAllProduct();
		if (productList == null)
			throw new ResponseStatusException(HttpStatus.NOT_FOUND);

		return new ResponseEntity<List<Product>>(productList, HttpStatus.OK);

	}

}
