package com.springboot.Product_Microservice.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.Product_Microservice.Entity.Product;
import com.springboot.Product_Microservice.Repository.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepo productRepo;

	public void addProduct(Product product) {
		productRepo.save(product);

	}

	@Override
	public void deleteProduct(int id) {
		Optional<Product> op = productRepo.findById(id);
		if (op.isPresent())
			productRepo.deleteById(id);

	}

	@Override
	public Product updateProduct(int id, Product product) {

		Optional<Product> op = productRepo.findById(id);
		if (op.isPresent()) {
			Product prod = op.get();
			prod.setProductName(product.getProductName());
			prod.setProductDescription(product.getProductDescription());
			prod.setProductPrice(product.getProductPrice());
			return productRepo.save(prod);
		}
		return null;

	}

	@Override
	public Product searchProduct(int id) {
		Optional<Product> op = productRepo.findById(id);
		return op.orElse(null); // Returns the Product object if present, otherwise null
	}

	@Override
	public List<Product> getAllProduct() {
		return productRepo.findAll();
	}
}
