package com.springboot.Product_Microservice.Exception;

/**
 * Custom exception class to indicate that a product was not found. Extends the
 * Exception class to provide specific error handling for cases where a product
 * is unavailable.
 */
public class ProductNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
	 * Constructs a new ProductNotFoundException with the specified detail message.
	 *
	 * @param msg the detail message
	 */
	public ProductNotFoundException(String msg) {
		super(msg); // Calls the parent constructor with the message
	}
}
