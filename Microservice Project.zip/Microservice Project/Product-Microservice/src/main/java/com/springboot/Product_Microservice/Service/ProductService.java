package com.springboot.Product_Microservice.Service;

import java.util.List;

import com.springboot.Product_Microservice.Entity.Product;

public interface ProductService {

	void addProduct(Product product);

	void deleteProduct(int id);

	Product updateProduct(int id, Product product);

	Product searchProduct(int id);

	List<Product> getAllProduct();
}
